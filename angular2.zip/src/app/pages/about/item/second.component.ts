import { Component } from '@angular/core';
@Component({
    selector:'about-item-second',
    template:`
        <h1>second</h1>
    `
})

export class SecondItemComponent{
}