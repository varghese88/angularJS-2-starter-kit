import { Component } from '@angular/core';
@Component({
    selector:'about-item-first',        
    template:`
        <h1>first</h1>
        
    `
})

export class FirstItemComponent{
}